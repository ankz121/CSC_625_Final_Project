﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace CSC_625_Project
{
    /// <summary>
    /// Interaction logic for AddCourse.xaml
    /// </summary>
    public partial class AddCourse : Window
    {
        String conStr;
        String userID;
        StudentPage parent;
        public AddCourse(StudentPage parent, String conStr, String userID)
        {
            this.parent = parent;
            this.conStr = conStr;
            this.userID = userID;
            InitializeComponent();

            using (SqlConnection con = new SqlConnection(conStr))
            {
                SqlCommand cmd = new SqlCommand("AvailableCourses", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@StudentID", userID));
                con.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        course_lb.Items.Add(reader["CourseID"].ToString());
                    }
                    reader.Close();
                }
                con.Close();
            }
        }

        private void btn_add_Click(object sender, RoutedEventArgs e)
        {
            String newCourse = course_lb.SelectedItem.ToString();

            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insertIntoCourse", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@StudentID", userID));
                cmd.Parameters.Add(new SqlParameter("@CourseID", newCourse));
                cmd.ExecuteNonQuery();

                parent.updateList();
                this.Hide();

            }
        }
    }
}
