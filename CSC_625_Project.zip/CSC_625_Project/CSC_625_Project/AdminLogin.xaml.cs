﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using System.Diagnostics;


namespace CSC_625_Project
{
    /// <summary>
    /// Interaction logic for AdminLogin.xaml
    /// </summary>
    public partial class AdminLogin : Window
    {
        String conStr;
        public AdminLogin(String conStr)
        {
            this.conStr = conStr;
            InitializeComponent();

        }

        private void btn_Login_Click(object sender, RoutedEventArgs e)
        {
            if (userID.Text.Length == 0)
            {
                MessageBox.Show("Username is empty. Please enter an ID.");

            }

            if (password.Password.Length == 0)
            {
                MessageBox.Show("Password field is empty. Please enter a password.");
            }

            else
            {

                using (SqlConnection con = new SqlConnection(conStr))
                {
                    SqlCommand cmd = new SqlCommand("AdminLoginCmd", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@Username", userID.Text));
                    cmd.Parameters.Add(new SqlParameter("@Passcode", password.Password));

                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();

                    sda.Fill(dt);

                    if (dt.Rows[0][0].ToString() == "1")
                    {
                        this.Hide();
                        new AdminPage(conStr).Show();
                    }
                    else
                    {
                        MessageBox.Show("Invalid username or password");
                    }
                }
            }

        }
    }
}
