﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace CSC_625_Project
{
    /// <summary>
    /// Interaction logic for StudentViewCourse.xaml
    /// </summary>
    public partial class StudentViewCourse : Window
    {
        String conStr;
        String userID;
        StudentPage parent;

        public StudentViewCourse(StudentPage parent, String conStr, String userID)
        {
            this.conStr = conStr;
            this.parent = parent;
            this.userID = userID;
            InitializeComponent();
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("ViewAllCourses", con);
                cmd.CommandType = CommandType.StoredProcedure;
                
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                viewcourseGrid.IsReadOnly = true;
                viewcourseGrid.ItemsSource = dt.DefaultView;

            }
        }

        private void view_course_back_btn_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            new StudentPage(conStr, userID).Show();
        }
    }
}
