﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CSC_625_Project
{
    /// <summary>
    /// Interaction logic for FacultyAddStudent.xaml
    /// </summary>
    public partial class FacultyAddStudent : Window
    {

        String conStr;
        String userID;
        FacultyCourse parent;


        public FacultyAddStudent(FacultyCourse parent, String conStr, String courseID, String userID)
        {
            this.parent = parent;
            this.conStr = conStr;
            this.userID = userID;

            InitializeComponent();

           
        }

        private void btn_addStudent_Click(object sender, RoutedEventArgs e)
        {
            String Studentid = studentID.Text;
            String courseID = courseid.Text;

            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insertIntoCourse", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@CourseID", courseID));
                cmd.Parameters.Add(new SqlParameter("@StudentID", Studentid));
                cmd.ExecuteNonQuery();
                this.Hide();

                new FacultyCourse(conStr,courseID,userID).Show();

            }
        }
    }
}
