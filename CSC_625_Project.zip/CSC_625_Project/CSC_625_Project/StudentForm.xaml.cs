﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace CSC_625_Project
{
    /// <summary>
    /// Interaction logic for CourseForm.xaml
    /// </summary>
    public partial class StudentForm : Window
    {
        String conStr;
        public StudentForm(String conStr)
        {
            this.conStr = conStr;
            InitializeComponent();
        }

        private void submitBtn_Click(object sender, RoutedEventArgs e)
        {
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("AddStudent", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@StudentID", Int32.Parse(idText.Text)));
                cmd.Parameters.Add(new SqlParameter("@LastName", lnameText.Text));
                cmd.Parameters.Add(new SqlParameter("@FirstName", fnameText.Text));
                cmd.Parameters.Add(new SqlParameter("@DOB", dobText.Text));
                cmd.Parameters.Add(new SqlParameter("@Email", emailText.Text));
                cmd.Parameters.Add(new SqlParameter("@Password", "password"));
                cmd.ExecuteNonQuery();
                this.Close();
            }
        }


    }
}