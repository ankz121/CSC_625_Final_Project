﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace CSC_625_Project
{
    /// <summary>
    /// Interaction logic for RemoveCourse.xaml
    /// </summary>
    public partial class RemoveCourse : Window
    {
        String conStr;
        public RemoveCourse(String conStr)
        {
            this.conStr = conStr;
            InitializeComponent();
            using (SqlConnection con = new SqlConnection(conStr))
            {
                SqlCommand cmd = new SqlCommand("AllCourses", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        course_lb.Items.Add(reader["CourseID"].ToString());
                    }
                    reader.Close();
                }
                con.Close();
            }
        }

        private void deleteBtn_Click(object sender, RoutedEventArgs e)
        {
            String course = course_lb.SelectedItem.ToString();

            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("DeleteCourse", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@CourseID", course));
                cmd.ExecuteNonQuery();

                this.Hide();

            }
        }
    }
}
