﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using System.Collections;

namespace CSC_625_Project
{
    /// <summary>
    /// Interaction logic for StudentPage.xaml
    /// </summary>
    public partial class StudentPage : Window
    {
        String conStr;
        String userID;
        public StudentPage(String conStr, String userID)
        {
            this.conStr = conStr;
            this.userID = userID;
            InitializeComponent();

            using (SqlConnection con = new SqlConnection(conStr))
            {
                SqlCommand cmd2 = new SqlCommand("nameSelect", con);
                cmd2.CommandType = CommandType.StoredProcedure;
                cmd2.Parameters.Add(new SqlParameter("@StudentID", userID));
                con.Open();
                SqlDataReader Name = cmd2.ExecuteReader();

                while (Name.Read())
                {
                    nameBox.Text = "Welcome "+ Name["Name"].ToString();
                }
                con.Close();
            }

            this.updateList();
        }        
        private void BtnSelect_OnClick(object sender, RoutedEventArgs e)
        {
            DataRowView dataRowView = (DataRowView)((Button)e.Source).DataContext;
            String courseID = dataRowView[0].ToString();
            new StudentCourse(this, conStr, courseID, userID).Show();
        }

        private void enroll_btn_Click(object sender, RoutedEventArgs e)
        {
            new AddCourse(this, conStr, userID).Show();
        }

        public void updateList()
        {
            using (SqlConnection con = new SqlConnection(conStr))
            {
                SqlCommand cmd = new SqlCommand("StudentCourses", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@StudentID", userID));
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                courseDG.IsReadOnly = true;
                courseDG.ItemsSource = dt.DefaultView;
            }
        }

        private void view_course_btn_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            new StudentViewCourse(this, conStr, userID).Show();
        }

        private void logout_btn_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            new MainWindow().Show();
        }
    }
}
