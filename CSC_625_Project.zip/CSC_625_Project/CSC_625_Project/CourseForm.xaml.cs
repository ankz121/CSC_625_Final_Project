﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace CSC_625_Project
{
    /// <summary>
    /// Interaction logic for CourseForm.xaml
    /// </summary>
    public partial class CourseForm : Window
    {
        String conStr;
        public CourseForm(String conStr)
        {
            this.conStr = conStr;
            InitializeComponent();
        }

        private void submitBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conStr))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("AddCourse", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@CourseID", idText.Text));
                    cmd.Parameters.Add(new SqlParameter("@CourseName", nameText.Text));
                    cmd.Parameters.Add(new SqlParameter("@CourseDesc", descText.Text));
                    cmd.Parameters.Add(new SqlParameter("@CourseTime", timeText.Text));
                    cmd.Parameters.Add(new SqlParameter("@CourseLoc", locText.Text));
                    cmd.ExecuteNonQuery();
                    this.Close();
                }
            }
            catch (Exception ex) { }
        }

    }
}
