﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace CSC_625_Project
{
    /// <summary>
    /// Interaction logic for FacultyCourse.xaml
    /// </summary>
    public partial class FacultyCourse : Window
    {
        String courseID;
        readonly String conStr;
        String userID;

        public FacultyCourse(String conStr, String courseID, String userID)
        {
            this.conStr = conStr;
            this.userID = userID;
            this.courseID = courseID;
            InitializeComponent();

            this.updateList();
        }

        private void btn_add_Click(object sender, RoutedEventArgs e)
        { 
             new FacultyAddStudent(this, conStr, courseID, userID).Show();
        }

        public void updateList()
        {
            using (SqlConnection con = new SqlConnection(conStr))
            {
                SqlCommand cmd = new SqlCommand("CourseEnrolled", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@CourseID", courseID));
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                courseDG.IsReadOnly = true;
                courseDG.ItemsSource = dt.DefaultView;
            }

        }
    }
}
