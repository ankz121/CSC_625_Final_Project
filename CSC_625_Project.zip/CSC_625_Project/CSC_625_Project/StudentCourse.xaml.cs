﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace CSC_625_Project
{
    /// <summary>
    /// Interaction logic for StudentCourse.xaml
    /// </summary>
    public partial class StudentCourse : Window
    {
        String courseID;
        String conStr;
        String userID;
        StudentPage parent;
        public StudentCourse(StudentPage parent, String conStr, String courseID, String userID)
        {
            this.parent = parent;
            this.courseID = courseID;
            this.userID = userID;
            this.conStr = conStr;
            InitializeComponent();
            using (SqlConnection con = new SqlConnection(conStr))
            {
                SqlCommand cmd = new SqlCommand("CourseInfo", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@CourseID", courseID));
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                courseDG.IsReadOnly = true;
                courseDG.ItemsSource = dt.DefaultView;

            }

        }

        private void btn_drop_Click(object sender, RoutedEventArgs e)
        {
            using (SqlConnection con = new SqlConnection(conStr))
            { 
                SqlCommand cmd = new SqlCommand("DropCourse", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@CourseID", courseID));
                con.Open();
                cmd.ExecuteNonQuery();
                parent.updateList();
                con.Close();

                this.Hide();
            }
        }
    }
}
