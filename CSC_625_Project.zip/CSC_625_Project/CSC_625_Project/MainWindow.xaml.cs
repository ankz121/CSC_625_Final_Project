﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using System.Diagnostics;

namespace CSC_625_Project
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
  
           

        }


        private void btn_Login_Click(object sender, RoutedEventArgs e)
        {
            if (userID.Text.Length == 0)
            {
                MessageBox.Show("Student ID/Faculty ID is empty. Please enter an ID.");

            }

            if (password.Password.Length == 0)
            {
                MessageBox.Show("Password field is empty. Please enter a password.");
            }

            else{

                String Eric = "Data Source = DESKTOP-EUSDVA4; Initial Catalog = College_Database; User ID = sa; Password = password";
                String Ankit = "Data Source = DESKTOP-8S7LHLA; Initial Catalog = College_Database; User ID = sa; Password = password";
                String Connor = "Data Source = DESKTOP-7SFGAT4; Initial Catalog = College_Database; User ID = sa; Password = password";

                String conStr = Eric;
                using (SqlConnection con = new SqlConnection(conStr))
                {
                    SqlCommand cmd = new SqlCommand("StudentLoginCmd", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@StudentID", userID.Text));
                    cmd.Parameters.Add(new SqlParameter("@Passcode", password.Password));

                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();

                    sda.Fill(dt);
                    if (dt.Rows[0][0].ToString() == "1")
                    {
                        this.Hide();
                        new StudentPage(conStr, userID.Text).Show();
                    }
                    else
                        MessageBox.Show("Invalid username or password");
                }
            }
        }
        private void ButtonFaculty_Click(object sender, RoutedEventArgs e)
        {
            String Eric = "Data Source = DESKTOP-EUSDVA4; Initial Catalog = College_Database; User ID = sa; Password = password";
            String Ankit = "Data Source = DESKTOP-8S7LHLA; Initial Catalog = College_Database; User ID = sa; Password = password";
            String Connor = "Data Source = DESKTOP-NENT6ON; Initial Catalog = College_Database; User ID = sa; Password = password";

            String conStr = Eric;
            new FacultyLogin(conStr).Show();
            this.Hide();
        }

        private void adminBtn_Click(object sender, RoutedEventArgs e)
        {
            String Eric = "Data Source = DESKTOP-EUSDVA4; Initial Catalog = College_Database; User ID = sa; Password = password";
            String Ankit = "Data Source = DESKTOP-8S7LHLA; Initial Catalog = College_Database; User ID = sa; Password = password";
            String Connor = "Data Source = DESKTOP-NENT6ON; Initial Catalog = College_Database; User ID = sa; Password = password";

            String conStr = Eric;
            new AdminLogin(conStr).Show();
            this.Hide();
        }
    }
}
