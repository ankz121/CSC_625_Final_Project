﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CSC_625_Project
{
    /// <summary>
    /// Interaction logic for AdminPage.xaml
    /// </summary>
    public partial class AdminPage : Window
    {
        String conStr;
        public AdminPage(String conStr)
        {
            this.conStr = conStr;
            InitializeComponent();
        }

        private void createcourseBtn_Click(object sender, RoutedEventArgs e)
        {
            new CourseForm(conStr).Show();
        }

        private void deletecourseBtn_Copy_Click(object sender, RoutedEventArgs e)
        {
            new RemoveCourse(conStr).Show();
        }

        private void addstudentBtn_Click(object sender, RoutedEventArgs e)
        {
            new StudentForm(conStr).Show();
        }

        private void removestudentBtn_Copy_Click(object sender, RoutedEventArgs e)
        {
            new RemoveStudent(conStr).Show();
        }

        private void addfacultyBtn_Click(object sender, RoutedEventArgs e)
        {
            new FacultyForm(conStr).Show();
        }

        private void removefacultyBtn_Copy_Click(object sender, RoutedEventArgs e)
        {
            new RemoveFaculty(conStr).Show();
        }
    }
}
